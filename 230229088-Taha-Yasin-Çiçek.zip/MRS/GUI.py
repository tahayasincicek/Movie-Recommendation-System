import pandas as pd
import tkinter as tk
from tkinter import StringVar
from random import sample
import customtkinter as ctk

# Veriyi yükleme adımı (örneğin, 'rules.csv' ve 'user_movie_matrix.csv' dosyalarını projeye ekledim)
rules = pd.read_csv(r"C:/Users/TAHA/Desktop/KOU/2024-2025 Güz Dönemi/Yazılım Geliştirme-I/archive1/rules2.csv")
user_movie_matrix = pd.read_csv(r"C:/Users/TAHA/Desktop/KOU/2024-2025 Güz Dönemi/Yazılım Geliştirme-I/archive1/user_movie_matrix.csv", index_col=0)
top_movies_by_genre_df = pd.read_csv(r"C:/Users/TAHA/Desktop/KOU/2024-2025 Güz Dönemi/Yazılım Geliştirme-I/archive1/top_movies_by_genre.csv")

ctk.set_appearance_mode("dark")

class RecommendationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Movie Recommendation System")

        # Öneri çıktısını görüntülemek için bir ekran hazırlıyorum
        self.output_label = ctk.CTkLabel(root, text="Recommended Movies:", font=("Helvetica", 14, "bold"))
        self.output_label.grid(row=0, column=0, columnspan=2, pady=10)
        self.output_text = ctk.CTkTextbox(root, height=85, width=500)
        self.output_text.grid(row=1, column=0, columnspan=2)

        # Kullanıcının öneri türünü seçmesi için bir seçenek kutusu oluşturuyorum
        self.recommendation_type_label = ctk.CTkLabel(root, text="Select Recommendation Type:", font=("Helvetica", 14, "bold"))
        self.recommendation_type_label.grid(row=2, column=0)
        self.recommendation_type_var = StringVar()
        self.recommendation_type_box = ctk.CTkComboBox(root, values=("Popular Movie Recommendations", "Personalized Movie Recommendations"), command=self.update_listbox_visibility)
        self.recommendation_type_box.grid(row=2, column=1)

        # Kullanıcının öneri kriterini seçmesi için bir seçenek kutusu oluşturuyorum
        self.criteria_label = ctk.CTkLabel(root, text="Select Recommendation Criteria:", font=("Helvetica", 14, "bold"))
        self.criteria_label.grid(row=3, column=0)
        self.criteria_var = StringVar()
        self.criteria_box = ctk.CTkComboBox(root, values=("By Movie Genre", "By Movie Name"), command=self.update_genre_listbox)
        self.criteria_box.grid(row=3, column=1)

        # Kullanıcının kişisel öneriler için seçebileceği bir kullanıcı listesi ekliyorum
        self.user_label = ctk.CTkLabel(root, text="Select User:", font=("Helvetica", 14, "bold"))
        self.user_label.grid(row=4, column=0)
        self.user_frame = ctk.CTkFrame(root)
        
        self.user_listbox = tk.Listbox(self.user_frame, height=5, width=30, bg="#2b2b2b", fg="white", selectbackground="#555555", selectforeground="white", font=("Helvetica", 12))
        self.user_listbox.pack(side=tk.LEFT, fill=tk.BOTH)
        
        self.user_scrollbar = tk.Scrollbar(self.user_frame, command=self.user_listbox.yview)
        self.user_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.user_listbox.configure(yscrollcommand=self.user_scrollbar.set)
        
        self.user_listbox.pack()
        self.user_listbox.insert(tk.END, *user_movie_matrix.index.tolist())
        self.user_frame.grid(row=5, column=0, padx=10, pady=10)

        # Tür bazlı öneriler için bir tür listesi ekliyorum
        self.genre_label = ctk.CTkLabel(root, text="Select Genre:", font=("Helvetica", 14, "bold"))
        self.genre_label.grid(row=4, column=1)
        self.genre_frame = ctk.CTkFrame(root)
        
        self.genre_listbox = tk.Listbox(self.genre_frame, height=5, width=30, bg="#2b2b2b", fg="white", selectbackground="#555555", selectforeground="white", font=("Helvetica", 12))
        self.genre_listbox.pack(side=tk.LEFT, fill=tk.BOTH)
        
        self.genre_scrollbar = tk.Scrollbar(self.genre_frame, command=self.genre_listbox.yview)
        self.genre_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.genre_listbox.configure(yscrollcommand=self.genre_scrollbar.set)
        
        self.genre_listbox.pack()
        self.genre_listbox.insert(tk.END, *top_movies_by_genre_df['selected_genre'].unique())
        self.genre_frame.grid(row=5, column=1, padx=10, pady=10)

        # Film ismine göre öneri yapılacaksa kullanıcıdan film ismini girmesini isteyeceğim bir giriş kutusu oluşturuyorum
        self.movie_name_label = ctk.CTkLabel(root, text="Enter Movie Name:", font=("Helvetica", 14, "bold"))
        self.movie_name_entry = ctk.CTkEntry(root, width=200)

        # Kullanıcının öneri alması için bir buton ekliyorum
        self.recommend_button = ctk.CTkButton(root, text="Make Recommendation", command=self.show_recommendation)
        self.recommend_button.grid(row=7, column=0, columnspan=2, pady=10)

        # Film ismi girişini başlangıçta gizliyorum
        self.movie_name_label.grid_remove()
        self.movie_name_entry.grid_remove()

    def update_listbox_visibility(self, selected_recommendation_type):
        # Öneri türü değiştirildiğinde kullanıcı veya tür listesi görünürlüğünü güncelleme
        if selected_recommendation_type == "Personalized Movie Recommendations":
            self.user_frame.grid()
        else:
            self.user_frame.grid_remove()

        if self.criteria_box.get() == "By Movie Genre":
            self.genre_frame.grid()
            self.movie_name_label.grid_remove()
            self.movie_name_entry.grid_remove()
        elif self.criteria_box.get() == "By Movie Name":
            self.genre_frame.grid_remove()
            self.movie_name_label.grid(row=6, column=0, padx=10, pady=5)
            self.movie_name_entry.grid(row=6, column=1, padx=10, pady=5)

    def update_genre_listbox(self, selected_criteria):
        # Öneri kriterine göre görünürlüğü güncelleme
        self.update_listbox_visibility(self.recommendation_type_box.get())

    def show_recommendation(self):
        recommendation_type = self.recommendation_type_box.get()
        criteria = self.criteria_box.get()
        recommendations = []  # Öneri listesini burada oluşturuyorum

        # Popüler film önerileri 
        if recommendation_type == "Popular Movie Recommendations":
            if criteria == "By Movie Genre":
                selected_genre = self.genre_listbox.get(tk.ACTIVE)
                genre_movies = top_movies_by_genre_df[top_movies_by_genre_df['selected_genre'] == selected_genre]
                recommendations = sample(genre_movies['title'].tolist(), min(5, len(genre_movies)))  # 5 film önerisi oluşturuyorum
                recommendation_info = f"Genre: {selected_genre}\n"
            elif criteria == "By Movie Name":
                movie_name = self.movie_name_entry.get()
                matching_rules = rules[rules['antecedents'].apply(lambda x: movie_name in x)]
                recommendations = sample(matching_rules['consequents'].explode().tolist(), 5) if not matching_rules.empty else ["No recommendations available"]
                recommendation_info = f"Based on Movie Name: {movie_name}\n"

        # Kişiselleştirilmiş film önerileri
        elif recommendation_type == "Personalized Movie Recommendations":
            selected_user = int(self.user_listbox.get(tk.ACTIVE))
            watched_movies = user_movie_matrix.columns[user_movie_matrix.loc[selected_user] > 0].tolist()
            recommendation_info = f"User: {selected_user}\n"

            if criteria == "By Movie Genre":
                selected_genre = self.genre_listbox.get(tk.ACTIVE)
                genre_movies = top_movies_by_genre_df[top_movies_by_genre_df['selected_genre'] == selected_genre]
                recommended_movies = set(genre_movies['title']) - set(watched_movies)
                recommendations = sample(list(recommended_movies), min(5, len(recommended_movies))) if recommended_movies else ["No recommendations available"]
                recommendation_info += f"Genre: {selected_genre}\n"

            elif criteria == "By Movie Name":
                movie_name = self.movie_name_entry.get()
                
                # Kullanıcının izlediği filmleri temel alarak ilişkili öneriler oluşturuyorum
                possible_rules = rules[rules['antecedents'].apply(lambda x: any(movie in x for movie in watched_movies))]
                related_movies = possible_rules['consequents'].explode().tolist()
                
                # Kullanıcının izlediği filmler dışında kalan önerileri seçiyorum
                recommendations = list(set(related_movies) - set(watched_movies))
                recommendations = sample(recommendations, min(5, len(recommendations))) if recommendations else ["No recommendations available"]
                recommendation_info += f"Based on Movie Name: {movie_name}\n"

        # Önerileri gösteriyorum
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, recommendation_info)
        for movie in recommendations:
            self.output_text.insert(tk.END, f"- {movie}\n")

# Uygulamanın ana kısmını başlatıyorum
root = ctk.CTk()
app = RecommendationApp(root)
root.mainloop()
